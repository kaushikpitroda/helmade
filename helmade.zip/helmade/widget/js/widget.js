jQuery(function () {
    jQuery('a').click(function (ev) {
        if (this.target !== '_blank') {
            jQuery("html, body").animate({scrollTop: 0}, 400);
            jQuery("#loading_overlay, #loading_overlay img").show().animate({opacity: 1}, 400);
            window.parent.postMessage({helmadeScrollToTop: true}, '*');
            return;
        }
    });
    
    var lastHelmadeHeight = 0;
    var overlay = jQuery("#loading_overlay");
    window.setInterval(function() {
        if (document.body.scrollHeight != lastHelmadeHeight && overlay.is(":hidden")) {
            lastHelmadeHeight = document.body.scrollHeight;
            window.parent.postMessage({helmadeHeight: lastHelmadeHeight}, '*');
        }
    }, 50);
});

window.addEventListener('message', function(ev) {
    var data = ev.data;
    if (typeof data == 'object' && typeof data.parentHeight == 'number' && typeof data.parentWidth == 'number') {
        if (data.parentHeight != window.parentHeight || data.parentWidth != window.parentWidth) {
            window.parentHeight = data.parentHeight;
            window.parentWidth = data.parentWidth;
            window.dispatchEvent(new Event('resize'));
        }
    }
});


