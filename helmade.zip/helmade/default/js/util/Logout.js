define([
        "log",
        "jquery"
    ],
    function (log, $) {
        "use strict";

        var Logout = {

            init: function () {

            }

        };

        return Logout;
    }
);
/**
 * Created by andi on 14.01.16.
 */
