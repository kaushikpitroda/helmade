define([], function () {

	path = "https://cdn.helmade.com/";

	return {
		path: path
	}
});