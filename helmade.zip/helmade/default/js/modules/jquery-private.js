define(["jquery"], function($) {
	return $.noConflict( true );
});