window.ias_config = {
    // options from https://github.com/webcreate/infinite-ajax-scroll
};

/* IS Custom Event to Hook into */
/*
jQuery(document).on('infiniteScrollReady',function(){
    console.log('bam!');
});
*/
