<?php
spl_autoload_register(function($name) {
    $exname = explode('\\', $name); 
    if ($exname[0] == 'GeoIp2' || $exname[0] == 'MaxMind') {
        $filename = Mage::getBaseDir() . '/lib/' . implode('/', $exname) . '.php';
        include $filename;
    }
});