<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_RequestQuote
 */


namespace Amasty\RequestQuote\Block\Cart\Item\Renderer\Actions;

class Actions extends \Magento\Checkout\Block\Cart\Item\Renderer\Actions
{
}
